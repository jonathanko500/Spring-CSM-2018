//project 4 part A
public class CashPayment extends Payment
{//start class
	public CashPayment()
	{
		super();
	}
	public CashPayment(double num, String aDate)
	{
		super(num,aDate);
	}
}//end class
