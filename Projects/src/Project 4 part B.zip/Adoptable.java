
public interface Adoptable 
{//start
	public String getHomeCareInstructions();
}//end
