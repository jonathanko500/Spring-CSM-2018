
public interface Amphibian
{//start
	public String LiveIn();
}//end
