
public interface Flyable
{//start
	public double getFlightSpeed();
}//end
