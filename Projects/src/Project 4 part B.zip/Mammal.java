
public interface Mammal 
{//start
	public boolean isWarmBlooded();
}//end
