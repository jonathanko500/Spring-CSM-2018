
public interface WaterLiveable
{//start
	public boolean canLiveOnLand();
}//end